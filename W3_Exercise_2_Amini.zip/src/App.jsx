import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import React, { useState } from 'react';


function App() {
    //massagge
    const [hideSuccess, setHideSuccess] = useState(true);
    const [hideError, setHideError] = useState(true);
    
    //createUser
    const[users, setUsers] = useState([]);
        
    const[id, setId] = useState(null);
    const[firstName, setFirstName] = useState('');
    const[lastName, setLastName] = useState('');
    const[department, setDepartment] = useState('');
    const[address, setAddress] = useState('');

    const handleChangeFirstName = (event) => {
		setFirstName(event.target.value);
	}

    const handleChangeLastName = (event) => {
        setLastName(event.target.value);
    }

    const handleChangeAddress = (event) => {
        setAddress(event.target.value);
    }

    const handleDropDownChange = (event) => {
        setDepartment(event.target.value);
    }

    const handleSubmit = (event) => {
    event.preventDefault();

    if (id == '' || firstName == '' || lastName == '' || department == '' || address == ''){
        handleError();
        return;
    }

    if(id === null){
        const newUser = { 
            id: Date.now().toString(),
            firstName: firstName,
            lastName: lastName,
            department: department,
            address: address
        }
        
        setUsers((prev) => [...prev,  newUser]);
        
    } else{
        const updatedUser = {
            id: id,
            firstName: firstName,
            lastName: lastName,
            department: department,
            address: address
        }
        
        const updatedUsers = users.map((user) => {
            if(user.id === updatedUser.id){
                return updatedUser;
            }
            return user;
        })
        setUsers(updatedUsers);
    }
    handleSuccess();
    handleResetForm();
}

    const handleSuccess = () => {
        setHideSuccess(false);
        setTimeout(() => {
            setHideSuccess(true);
        }, 5000);
    }

    const handleError = () => {
        setHideError(false);
        setTimeout(() => {
            setHideError(true);
        }, 5000);

    }


    const handleDelete = (event) => {
        event.preventDefault();
        setUsers((prev) => prev.filter((user) => user.id !== event.target.value));
    }

    const handleEdit = (event) => {
        const user = users.filter((user) => user.id === event.target.value)[0];
        setId(user.id);
        setFirstName(user.firstName);
        setLastName(user.lastName);
        setDepartment(user.department);
        setAddress(user.address);
    }

    const handleResetForm = () => {
        setId(null);
        setFirstName('');
        setLastName('');
        setDepartment('');
        setAddress('');
    }


  return (
    <div className="container d-flex flex-column justify-content-center align-items-center m-0">
          <h1 className='text-center font-weight-bold py-4'>Registration Form</h1>
        <div className="row" style={{maxWidth: '60%'}}>
            <div className="alert alert-success" hidden={hideSuccess}>
                Data has been saved successfully
            </div>
            <div className="alert alert-danger" hidden={hideError}>
                Data Error
            </div>

            <div className="col-4">
                <div className="card">
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="mb-3">
                                <label htmlFor="firstName" className="form-label">First Name</label>
                                <input type="text" name="firstName" className="form-control" id="firstName" value={firstName} onChange={handleChangeFirstName}/>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="lastName" className="form-label">Last Name</label>
                                <input type="text" name="lastName" className="form-control" id="lastName" value={lastName} onChange={handleChangeLastName}/>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="department" className="form-label">Department</label>
                                <select className="form-select" name="department" aria-label="Default select example" value={department} onChange={handleDropDownChange}>
                                        <option value=" ">Please choose one</option>
                                        <option value="Data Management">Data Management</option>
                                        <option value="Finance, HR & Administration">Finance, HR & Administration</option>
                                        <option value="Product Development & Operation">Product Development & Operation</option>
                                </select>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="address" className="form-label">Address</label>
                                <textarea name="address" className="form-control" id="address" rows="3" value={address} onChange={handleChangeAddress}></textarea>
                            </div>
                            <div className="d-grid gap-2">
                                <button type="submit" className="">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div className="col-8">
            <div className="card" style={{background: '#00494d'}}>
                      <div className="card-header text-white">
                        <strong>USER LIST</strong>
                    </div>
                    <div className="card-body">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">	Address</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    users.map((user, index) =>  (
                                            <tr key={index}>
                                                <th scope="row">{index + 1}</th>
                                                <td>{user.firstName + " " + user.lastName}</td>
                                                <td>{user.department}</td>
                                                <td>{user.address}</td>
                                                <td>
                                                    <button className="btn btn-warning btn-sm" value={user.id} onClick={handleEdit}>Edit</button>
                                                    <button className="btn btn-danger btn-sm" value={user.id} onClick={handleDelete} >Delete</button>
                                                </td>
                                            </tr>
                                        )
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
)
}

export default App;
